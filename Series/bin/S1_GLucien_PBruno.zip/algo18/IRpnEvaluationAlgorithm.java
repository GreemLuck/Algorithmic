package algo18;

public interface IRpnEvaluationAlgorithm
{
    double evaluateExpression(Queue<Token> inputQueue);
}
