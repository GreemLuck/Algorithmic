package algo18;

public class ShuntingYardAlgorithm implements IShuntingYardAlgorithm
{
    @Override
    public Queue<Token> convertToRPN(Queue<Token> input)
    {
        throw new UnsupportedOperationException();
    }
}
